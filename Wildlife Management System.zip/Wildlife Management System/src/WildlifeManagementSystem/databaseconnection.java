/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package WildlifeManagementSystem;

/**
 *
 * @author DEEPA K
 */
import java.sql.*;
import java.sql.DriverManager;


public class databaseconnection {
    Connection con;
    ResultSet res;
    PreparedStatement ps;
    public static Connection connectdb()
    {
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","password");
            return con;
        }
        catch(Exception e)
        {
            e.getMessage();
            return null;
        }
    }
    public static void main(String args[])
    {
        connectdb();
    }
}