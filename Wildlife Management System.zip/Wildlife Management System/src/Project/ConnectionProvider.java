/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Project;
import java.sql.*;

/**
 *
 * @author DEEPA K

public class ConnectionProvider {
   public static Connection getCon()
   {
     try
     {
         Class.forName("oracle.jdbc.driver.OracleDriver");
         Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Scott","tiger");
         return con;
     }
     catch(Exception e)
     {
         System.out.println(e);
          return null; 
     }
   }
   public static void main(String args[])
    {
        getCon();
    }
}*/


public class ConnectionProvider {
    Connection con;
    ResultSet res;
    PreparedStatement ps;
    public static Connection connectdb()
    {
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","9387");
            return con;
        }
        catch(Exception e)
        {
            e.getMessage();
            return null;
        }
    }
    public static void main(String args[])
    {
        connectdb();
    }
}